-- Insertion Data for Populating Table

--Insert in Doctor
--SELECT * FROM Doctor
insert into Doctor (first_name, middle_name, last_name, date_of_birth, phone_number, address, username, pass) values('Lacey','S','Smith','1980-08-19','9991199999','221 B Drive Tx','Lsmith','passwd');
insert into Doctor (first_name, middle_name, last_name, date_of_birth, phone_number, address, username, pass) values('Ada','T','Shelby','1984-08-19','9999994444','22 N Glenville Drive Tx','Ashelby','passwd');
insert into Doctor (first_name, middle_name, last_name, date_of_birth, phone_number, address, username, pass) values('Abi','M','Shawn','19989-06-11','8888856568','10 Campbell Rd Richardson','Ashawn','pass');
insert into Doctor (first_name, middle_name, last_name, date_of_birth, phone_number, address, username, pass) values('David','','Fox','1986-06-12','7777773456','122 Campbell Rd Richardson','Dfox','password');
insert into Doctor (first_name, middle_name, last_name, date_of_birth, phone_number, address, username, pass) values('John','H','Smith','1972-06-01','8888667890','153 Campbell Rd Richardson','JHeather','pass');

--Insert in Patient
--SELECT * FROM Patient
insert into Patient (first_name, middle_name, last_name, gender, date_of_birth, phone_number, address, username, pass) values('Nick','j','Morgan','M','2000-08-09','1234567890','3000 N Blvd TX','Nmorgan','pass');
insert into Patient (first_name, middle_name, last_name, gender, date_of_birth, phone_number, address, username, pass) values('Adam','','Smith','F','1994-08-19','9999999999','2210 N Glen Drive Tx','Asmith','passwd');
insert into Patient (first_name, middle_name, last_name, gender, date_of_birth, phone_number, address, username, pass) values('Abby','M','Vaupel','F','1999-06-11','8888888888','100 Campbell Rd Richardson','Avaupel','pass');
insert into Patient (first_name, middle_name, last_name, gender, date_of_birth, phone_number, address, username, pass) values('Diana','','Denisse','F','1996-06-12','7777777777','120 Campbell Rd Richardson','Ddenisse','password');
insert into Patient (first_name, middle_name, last_name, gender, date_of_birth, phone_number, address, username, pass) values('Jil','H','Heather','M','1992-06-01','8888668888','143 Campbell Rd Richardson','JHeather','pass');

--Insert in Admins
--SELECT * FROM Admins
insert into Admins (first_name, middle_name, last_name, phone_number, username, pass) values('Natasha','S','George','0010010000','Ngeorge','password');
insert into Admins (first_name, middle_name, last_name, phone_number, username, pass) values('James','T','Murphy','0020020000','Jmurphy','passwd');
insert into Admins (first_name, middle_name, last_name, phone_number, username, pass) values('Harley','M','Ford','0030030000','Hford','pass');
insert into Admins (first_name, middle_name, last_name, phone_number, username, pass) values('Kendra','','Roses','0040040000','Kroses','passwrd');
insert into Admins (first_name, middle_name, last_name, phone_number, username, pass) values('Agatha','H','Vega','0050050000','Avega','passdrw');

--Insert Services
--SELECT * FROM Services
insert into Services (service_name, cost_of_service) values('Medical Treatment', '10000.00');
insert into Services (service_name, cost_of_service) values('Surgery','100000.00');
insert into Services (service_name, cost_of_service) values('Counseling','100.00');
insert into Services (service_name, cost_of_service) values('Diagnosis','1000.00');
insert into Services (service_name, cost_of_service) values('Educational Services','0.0');

--Insert Appointments
--SELECT * FROM Appointment
insert into Appointment (datetime, status, meeting_link, patient_id, doctor_id, service_id) values('2022-11-18 10:30:00 AM','Confirm','https://telemed.domain/link','5','3','1');
insert into Appointment (datetime, status, meeting_link, patient_id, doctor_id, service_id) values('2022-11-18 11:30:00 AM','Pending','https://telemed.domain/link','5','5','1');
insert into Appointment (datetime, status, meeting_link, patient_id, doctor_id, service_id) values('2022-11-18 12:30:00 AM','Waitlist','https://telemed.domain/link','4','2','5');
insert into Appointment (datetime, status, meeting_link, patient_id, doctor_id, service_id) values('2022-12-18 10:30:00 AM','Confirm','https://telemed.domain/link','1','4','2');
insert into Appointment (datetime, status, meeting_link, patient_id, doctor_id, service_id) values('2022-12-18 11:00:00 AM','Confirm','https://telemed.domain/link','2','3','4');

--Insert Payment
--SELECT * FROM Payment
insert into Payment (status, proof_of_payment, admin_id) values('Confirm','https://telemed.domain/link_to__payment_confirmation','1');
insert into Payment (status, proof_of_payment, admin_id) values('Pending','https://telemed.domain/link_to__payment_confirmation','1');
insert into Payment (status, proof_of_payment, admin_id) values('Pending','https://telemed.domain/link_to__payment_confirmation','5');
insert into Payment (status, proof_of_payment, admin_id) values('Confirm','https://telemed.domain/link_to__payment_confirmation','2');
insert into Payment (status, proof_of_payment, admin_id) values('Confirm','https://telemed.domain/link_to__payment_confirmation','4');

--Insert Has
--SELECT * FROM Has
insert into Has values('1','1', 50.00);
insert into Has values('1','4', 20.00);
insert into Has values('5','3', 5.00);
insert into Has values('2','3', 100.00);
insert into Has values('4','2', 73.00);
insert into Has values('3','1', 0.25);














