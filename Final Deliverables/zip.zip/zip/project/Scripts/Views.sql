


CREATE OR REPLACE VIEW PatientPaymentInformation
AS
	SELECT 
		CONCAT(p.first_name, ' ', p.last_name) Patient,
		CONCAT('Dr. ', d.first_name, ' ', d.last_name) Doctor,
		s.cost_of_service Service_Cost,
		SUM(h.amount) Amount_Paid,
		s.cost_of_service - SUM(h.amount) Cost_Remaining
	FROM Appointment apt
	JOIN Has h ON h.appointment_id = apt.appointment_id
	JOIN Payment pay ON pay.payment_id = h.payment_id
	JOIN Patient p ON p.patient_id = apt.patient_id
	JOIN Doctor d ON d.doctor_id = apt.doctor_id
	JOIN Services s ON s.service_id = apt.service_id
	GROUP BY 
		p.patient_id,
		p.first_name,
		p.last_name, 
		d.doctor_id,
		d.first_name, 
		d.last_name, 
		s.service_id,
		s.cost_of_service
	;



CREATE OR REPLACE VIEW PatientAppointments
AS
	SELECT 
		CONCAT(p.first_name, ' ', p.last_name) Patient,
		apt.datetime Appointment_DateTime, 
		apt.status Appointment_Status
	FROM Appointment apt
	JOIN Patient p ON p.patient_id = apt.patient_id
	;



CREATE OR REPLACE VIEW DoctorAppointments
AS
	SELECT 
		CONCAT('Dr. ', d.first_name, ' ', d.last_name) Doctor,
		apt.datetime Appointment_DateTime, 
		apt.status Appointment_Status
	FROM Appointment apt
	JOIN Doctor d ON d.doctor_id = apt.doctor_id
	;
	
	

