
-- 1. Get all appointment information for a single patient
SELECT 
	apt.status Appointment_Status, 
	apt.meeting_link Link, 
	CONCAT('Dr. ', d.first_name, ' ', d.last_name) Doctor,
	s.service_name Service
FROM Appointment apt
JOIN Doctor d ON d.doctor_id = apt.doctor_id
JOIN Services s ON s.service_id = apt.service_id
WHERE patient_id = 5
;

-- 2. Get all confirmed appointment information for a single patient
SELECT 
	apt.status Appointment_Status, 
	apt.meeting_link Link, 
	CONCAT('Dr. ', d.first_name, ' ', d.last_name) Doctor,
	s.service_name Service
FROM Appointment apt
JOIN Doctor d ON d.doctor_id = apt.doctor_id
JOIN Services s ON s.service_id = apt.service_id
WHERE 
	patient_id = 5
	AND
	apt.status = 'Confirm'
;

-- 3. Get patient, confrimed appointment time, and service by doctor
SELECT p.last_name, p.first_name, apt.datetime, s.service_name, apt.status
FROM Appointment apt
JOIN Patient p ON p.patient_id = apt.patient_id
JOIN Services s ON s.service_id = apt.service_id
WHERE 
	apt.doctor_id = 3
	AND
	apt.status = 'Confirm'
;

-- 4. Get appointments and their payment info for patient
SELECT 
	apt.datetime Appointment_Time,
	apt.status Appointment_Status,
	CONCAT('Dr. ', d.first_name, ' ', d.last_name) Doctor,
	s.cost_of_service Service_Cost,
	SUM(h.amount) Amount_Paid,
	s.cost_of_service - SUM(h.amount) Cost_Remaining
FROM Appointment apt
JOIN Has h ON h.appointment_id = apt.appointment_id
JOIN Payment pay ON pay.payment_id = h.payment_id
JOIN Doctor d ON d.doctor_id = apt.doctor_id
JOIN Services s ON s.service_id = apt.service_id
WHERE apt.patient_id = 1
GROUP BY 
	apt.appointment_id, 
	apt.datetime, 
	apt.status, 
	d.doctor_id,
	d.first_name, 
	d.last_name, 
	s.service_id,
	s.cost_of_service
;

-- 5. Get services
SELECT *
FROM Services
;

-- 6. Get pending payments for admin to confirm
SELECT 
	CONCAT(p.first_name, ' ', p.last_name) Patient,
	CONCAT('Dr. ', d.first_name, ' ', d.last_name) Doctor,
	s.cost_of_service Service_Cost,
	SUM(h.amount) Amount_Paid,
	s.cost_of_service - SUM(h.amount) Cost_Remaining
FROM Payment pay
JOIN Has h ON h.payment_id = pay.payment_id
JOIN Appointment apt ON apt.appointment_id = h.appointment_id
JOIN Patient p ON p.patient_id = apt.patient_id
JOIN Doctor d ON d.doctor_id = apt.doctor_id
JOIN Services s ON s.service_id = apt.service_id
WHERE 
	pay.admin_id = 1
	AND
	pay.status = 'Pending'
GROUP BY 
	pay.payment_id,
	p.patient_id,
	p.first_name,
	p.last_name, 
	d.doctor_id,
	d.first_name, 
	d.last_name, 
	s.service_id,
	s.cost_of_service
;

-- 7. Get number of appointments per patient
SELECT 
	CONCAT(p.first_name, ' ', p.last_name) Patient,
	COUNT(apt.appointment_id) Number_of_Appointments
FROM Patient p
JOIN Appointment apt ON apt.patient_id = p.patient_id
GROUP BY
	p.patient_id, 
	p.first_name,
	p.last_name
;








